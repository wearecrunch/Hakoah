<?php defined("SYSPATH") or die("No direct script access.") ?>
<div class="g-block">
  <h1> <?= t("Comment settings") ?> </h1>
  <div class="g-block-content">
    <?= $form ?>
  </div>
</div>
